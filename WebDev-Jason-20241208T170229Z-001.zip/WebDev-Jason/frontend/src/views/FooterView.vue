<script setup></script>
<template>
  <div class="fixed-bottom text-center bg-dark text-light">
    WEB DEVELOPMENT COURSE @BINUS UNIVERSITY 2024
  </div>
</template>
